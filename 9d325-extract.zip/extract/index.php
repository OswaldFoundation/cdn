<?php

	require_once __DIR__ . '/vendor/autoload.php';
	use Goose\Client as GooseClient;

	if (isset($_GET["url"])) {
		$url = $_GET["url"];
	} else {
		$url = "http://minet.co";
	}

	function decode($string) {
		$string = str_replace("ana_d2", ".", $string);
		$string = str_replace("rt678u", "/", $string);
		$string = str_replace("r_2", ":", $string);
		$string = urldecode($string);
		$string = str_rot13($string);
		return $string;
	}

	$goose = new GooseClient();
	$article = $goose->extractContent(decode($url));
	$title = $article->getTitle();
	$metaDescription = $article->getMetaDescription();
	$metaKeywords = $article->getMetaKeywords();
	$canonicalLink = $article->getCanonicalLink();
	$domain = $article->getDomain();
	$tags = $article->getTags();
	$links = $article->getLinks();
	$videos = $article->getVideos();
	$entities = $article->getPopularWords();
	$image = $article->getTopImage();
	$allImages = $article->getAllImages();
	$articleText = str_replace("\n", "<br>", $article->getCleanedArticleText());

echo '
		<style>
			body {
				font-family: sans-serif;
				max-width: 720px;
				width: 90%;
				font-size: 106%;
				margin: 7.5vh auto;
				line-height: 1.5;
			}
			[data-oswald] {
				position: absolute; right: 10px; top: 10px;
			}
		</style><button data-oswald>Accessibility</button>
	';
	echo "<title>$title</title><h1>$title</h1><div class='content'>$articleText</div>";	echo '<script>(function(){a=document.createElement("script");a.src="//oswald.host/agastya.js";b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b);document.agastya={key:"3e40063e25753005ccb971c164035b1a"}})();</script>';


?>