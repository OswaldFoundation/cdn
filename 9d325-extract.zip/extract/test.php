<?php

	echo '
		<style>
			body {
				font-family: sans-serif;
				max-width: 720px;
				width: 90%;
				font-size: 106%;
				margin: 7.5vh auto;
				line-height: 1.5;
			}
			[data-oswald] {
				position: absolute; right: 10px; top: 10px;
			}
		</style><button data-oswald>Accessibility</button>
	';

	echo "<h1>MINET X</h1><div class='content'>Introducing Make.<br><br>Humans innovate.<br><br>When faced with the seemingly insurmountable, we resort to our inherent ingenuity to deal with it. We make things. Things of utility. Things of majesty. Things that make you stop and think how you didn’t think of a solution so elegant to a problem so daunting.<br><br>Every once in a while, one of these things also happens to be a thing of beauty. A paragon of design.<br><br>At X, we celebrate just that. And try our best to Make.</div>";

	echo '<script>(function(){a=document.createElement("script");a.src="//oswald.host/agastya.js";b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b);document.agastya={key:"3e40063e25753005ccb971c164035b1a"}})();</script>';

?>