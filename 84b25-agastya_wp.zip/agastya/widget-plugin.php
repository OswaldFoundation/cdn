<?php
/*
Plugin Name: Agastya Accessibility
Plugin URI: https://oswald.foundation/agastya
Description: Add accessibility features to your WordPress site
Version: 0.92
Author: Oswald Foundation
Author URI: https://oswald.foundation
License: GPL2
*/

	class agastya_wp extends WP_Widget {

		function agastya_wp() {
			parent::WP_Widget(false, $name = __("Agastya Accessibility", "wp_widget_plugin") );
		}

		function form($instance) {	
			if ($instance) {
				$title = esc_attr($instance["title"]);
				$textarea = esc_textarea($instance["textarea"]);
			} else {
				$title = "";
				$textarea = "";
			} ?>
			<p> <label for="<?php echo $this->get_field_id("title"); ?>"><?php _e("Widget Title", "wp_widget_plugin"); ?></label> <input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo $title; ?>"> </p>
			<p> <label for="<?php echo $this->get_field_id('textarea'); ?>"><?php _e('Custom CSS:', 'wp_widget_plugin'); ?></label> <textarea class="widefat" id="<?php echo $this->get_field_id('textarea'); ?>" name="<?php echo $this->get_field_name('textarea'); ?>"><?php echo $textarea; ?></textarea> </p>
			<?php
		}

		function update($new_instance, $old_instance) {
			$instance = $old_instance;
			$instance["title"] = strip_tags($new_instance["title"]);
			$instance["textarea"] = strip_tags($new_instance["textarea"]);
			return $instance;
		}

		function widget($args, $instance) {
			extract($args);
			$title = apply_filters("widget_title", $instance["title"]);
			$textarea = apply_filters("widget_title", $instance["textarea"]);
			echo $before_widget;
			echo '<div class="widget-text wp_widget_plugin_box">';
			if ($title) {
				echo $before_title . $title . $after_title;
			}
			if ($textarea) {
				echo '<button data-oswald style="' . $textarea . '">Accessibility Options</button>';
			} else {
				echo '<button data-oswald>Accessibility Options</button>';
			}
			echo '</div>';
			wp_enqueue_script("script-name", "//oswald.host/agastya.js", array(), "1.0.0", true);
			echo $after_widget;
		}
	}

	add_action("widgets_init", create_function("", "return register_widget(\"agastya_wp\");"));

?>