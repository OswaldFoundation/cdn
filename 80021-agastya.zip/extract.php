<?php

	require_once __DIR__ . '/vendor/autoload.php';
	use Goose\Client as GooseClient;

	$goose = new GooseClient();
	$article = $goose->extractContent($_GET["url"]);
	$title = $article->getTitle();
	$metaDescription = $article->getMetaDescription();
	$metaKeywords = $article->getMetaKeywords();
	$canonicalLink = $article->getCanonicalLink();
	$domain = $article->getDomain();
	$tags = $article->getTags();
	$links = $article->getLinks();
	$videos = $article->getVideos();
	$entities = $article->getPopularWords();
	$image = $article->getTopImage();
	$allImages = $article->getAllImages();
	$articleText = str_replace("\n", "<br>", $article->getCleanedArticleText());

	echo "<h1>$title</h1><div class='content'>$articleText</div>";

?>